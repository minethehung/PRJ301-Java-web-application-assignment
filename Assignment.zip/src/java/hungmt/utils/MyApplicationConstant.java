/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hungmt.utils;

/**
 *
 * @author PC
 */
public class MyApplicationConstant {

    public class AddToCartFeatures {

        public static final String VIEW_SHOPPING_PAGE = "viewShoppingPage";
    }

    public class CheckoutFeatures {

        public static final String VIEW_SHOPPING_PAGE = "viewShoppingPage";
    }

    public class CreateAccountFeatures {

        public static final String ERROR_PAGE = "createAccountPage";
        public static final String LOGIN_PAGE = "";
    }

    public class DeleteAccountFeatures {

        public static final String ERROR_PAGE = "errorPage";
    }

    public class LoginFeatures {

        public static final String INVALID_PAGE = "invalidPage";
        public static final String SEARCH_PAGE = "searchPage";
    }

    public class LogoutFeatures {

        public static final String LOGIN_PAGE = "";
        public static final String ERROR_PAGE = "errorPage";
    }
    public class RemoveBookFeatures {
         public static final String VIEW_CART_SERVLET = "viewCartServlet";
    }
    public class SearchLastnameFeatures {
         public static final String SEARCH_PAGE = "searchPage";
    }
    public class UpdateAccountFeatures {
        public static final String ERROR_PAGE = "errorPage";
    }
    public class ViewBookFeatures {
        public static final String SHOPPING_PAGE = "shoppingPage";
    }
    public class ViewCartFeatures {
         public static final String VIEW_CART_PAGE = "viewCartPage";
    }
}
